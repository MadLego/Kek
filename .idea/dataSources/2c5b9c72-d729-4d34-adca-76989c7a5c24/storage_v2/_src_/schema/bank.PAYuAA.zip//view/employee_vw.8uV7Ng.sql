CREATE VIEW employee_vw AS
  SELECT
    `bank`.`employee`.`emp_id`           AS `emp_id`,
    `bank`.`employee`.`fname`            AS `fname`,
    `bank`.`employee`.`lname`            AS `lname`,
    year(`bank`.`employee`.`start_date`) AS `start_year`
  FROM `bank`.`employee`;

